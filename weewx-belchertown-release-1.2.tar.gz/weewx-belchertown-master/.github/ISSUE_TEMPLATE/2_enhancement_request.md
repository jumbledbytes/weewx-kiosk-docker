---
name: Enhancement Request
about: Got an idea to enhance the skin?
title: ''
labels: 'enhancement'
assignees: ''

---

:bulb: **The Idea**
<!-- Share your thoughts; try to be detailed if you can -->


:hammer: **Breaking Feature**
<!-- Would your idea disrupt or drastically change the flow
   of Apprise or how it currently works? If so explain it here.  -->


**HELP WANTED**
If you have a fix for this, please submit a pull request against the development branch! 